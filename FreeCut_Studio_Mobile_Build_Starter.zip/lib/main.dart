import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  MediaKit.ensureInitialized();
  runApp(const FreeCutApp());
}

class FreeCutApp extends StatelessWidget {
  const FreeCutApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FreeCut Studio',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF7C5CFF),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF101014),
        useMaterial3: true,
      ),
      home: const EditorPage(),
    );
  }
}

class EditorPage extends StatefulWidget {
  const EditorPage({super.key});

  @override
  State<EditorPage> createState() => _EditorPageState();
}

class _EditorPageState extends State<EditorPage> {
  late final Player _player;
  late final VideoController _videoController;
  String? _videoPath;
  String _status = '先匯入影片，開始你的第一個專案';
  double _startTrim = 0;
  double _endTrim = 100;

  @override
  void initState() {
    super.initState();
    _player = Player();
    _videoController = VideoController(_player);
  }

  Future<void> _importVideo() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.video,
        allowMultiple: false,
      );
      if (result == null || result.files.single.path == null) return;
      final path = result.files.single.path!;
      await _player.open(Media(path), play: false);
      if (!mounted) return;
      setState(() {
        _videoPath = path;
        _status = '已匯入：${path.split(Platform.pathSeparator).last}';
        _startTrim = 0;
        _endTrim = 100;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _status = '無法開啟影片：$e');
    }
  }

  void _showComingSoon(String feature) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$feature 正在規劃中，這是第一版原型。')),
    );
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.movie_creation_outlined, color: Color(0xFFB8A7FF)),
            SizedBox(width: 10),
            Text('FreeCut Studio', style: TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: FilledButton.icon(
              onPressed: () => _showComingSoon('匯出影片'),
              icon: const Icon(Icons.file_upload_outlined),
              label: const Text('匯出'),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final wide = constraints.maxWidth >= 800;
            final preview = _buildPreview();
            final tools = _buildTools();
            if (wide) {
              return Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(flex: 3, child: preview),
                  SizedBox(width: 320, child: tools),
                ],
              );
            }
            return Column(
              children: [
                Expanded(flex: 3, child: preview),
                SizedBox(height: 300, child: tools),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildPreview() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFF050507),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.white12),
              ),
              clipBehavior: Clip.antiAlias,
              child: _videoPath == null
                  ? const Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.video_library_outlined, size: 58, color: Colors.white38),
                          SizedBox(height: 12),
                          Text('影片預覽區', style: TextStyle(fontSize: 18)),
                          SizedBox(height: 6),
                          Text('匯入影片後，就能在這裡預覽', style: TextStyle(color: Colors.white54)),
                        ],
                      ),
                    )
                  : Video(controller: _videoController, fit: BoxFit.contain),
            ),
          ),
          const SizedBox(height: 12),
          Text(_status, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 12),
          Wrap(
            alignment: WrapAlignment.center,
            spacing: 10,
            runSpacing: 8,
            children: [
              OutlinedButton.icon(
                onPressed: _importVideo,
                icon: const Icon(Icons.add),
                label: const Text('匯入影片'),
              ),
              IconButton.filledTonal(
                tooltip: '播放 / 暫停',
                onPressed: _videoPath == null
                    ? null
                    : () async {
                        if (_player.state.playing) {
                          await _player.pause();
                        } else {
                          await _player.play();
                        }
                      },
                icon: const Icon(Icons.play_arrow),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTools() {
    return Container(
      margin: const EdgeInsets.fromLTRB(8, 8, 16, 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF19191F),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white10),
      ),
      child: ListView(
        children: [
          const Text('編輯工具', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          const Text('第一版：影片匯入與預覽', style: TextStyle(color: Colors.white54)),
          const SizedBox(height: 16),
          _toolTile(Icons.content_cut, '剪輯 / 分割', '設定片段起點與終點', () => _showComingSoon('剪輯 / 分割')),
          _toolTile(Icons.text_fields, '文字與字幕', '加入標題與字幕', () => _showComingSoon('文字與字幕')),
          _toolTile(Icons.music_note, '音樂與音效', '加入自己的音訊檔', () => _showComingSoon('音樂與音效')),
          _toolTile(Icons.auto_awesome, '濾鏡與特效', '免費基礎效果', () => _showComingSoon('濾鏡與特效')),
          _toolTile(Icons.speed, '速度調整', '慢動作或加速', () => _showComingSoon('速度調整')),
          const SizedBox(height: 8),
          const Divider(color: Colors.white12),
          const Text('時間軸（介面預覽）', style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Container(
            height: 58,
            decoration: BoxDecoration(
              color: const Color(0xFF29243F),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: const Color(0xFF8D78FF)),
            ),
            child: Row(
              children: [
                const SizedBox(width: 10),
                const Icon(Icons.movie, color: Color(0xFFB8A7FF)),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _videoPath == null ? '尚未匯入影片' : _videoPath!.split(Platform.pathSeparator).last,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const SizedBox(width: 10),
              ],
            ),
          ),
          const SizedBox(height: 14),
          const Text('預計支援：無浮水印、無訂閱鎖定、免費匯出',
              style: TextStyle(color: Color(0xFFB8A7FF), fontSize: 12)),
        ],
      ),
    );
  }

  Widget _toolTile(IconData icon, String title, String subtitle, VoidCallback onTap) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: const Color(0xFF29243F),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(icon, color: const Color(0xFFB8A7FF)),
      ),
      title: Text(title),
      subtitle: Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.white54)),
      trailing: const Icon(Icons.chevron_right, color: Colors.white38),
      onTap: onTap,
    );
  }
}
