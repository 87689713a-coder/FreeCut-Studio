# FreeCut Studio（手機製作入門包）

這是 FreeCut Studio 的早期 Flutter 原型，另附 GitHub Actions 工作流程，嘗試在雲端編譯 Android APK。

## 現有原型功能
- 深色剪輯器介面
- 從裝置選取影片
- 影片預覽與播放／暫停
- 手機和桌面寬度的響應式介面

## 目前還沒有完成的功能
剪輯、分割、字幕、音樂軌、特效和 MP4 匯出按鈕目前只是規劃／佔位，尚不能當作完整影片剪輯器使用。

## 只有 Android 手機，如何嘗試產生 APK
1. 在瀏覽器開啟 GitHub，登入或建立帳號。
2. 建立一個新的 repository（儲存庫），建議名稱 `freecut-studio`。
3. 將此 ZIP 解壓縮後，把裡面的所有檔案和資料夾上傳到儲存庫根目錄。請確認 `.github/workflows/build-apk.yml` 也有上傳。
4. 在 GitHub 儲存庫開啟 **Actions** 分頁。
5. 選擇 **Build FreeCut Studio APK** 工作流程，按 **Run workflow**。若剛上傳到 `main` 分支，通常也會自動開始建置。
6. 等待工作流程完成。若成功，開啟該次工作流程頁面最下方的 **Artifacts**，下載 `freecut-studio-apk`。
7. 解壓縮 Artifact，找到 `app-release.apk`，再於自己的 Android 手機上安裝。

GitHub 的免費使用額度、帳號驗證和介面可能變動；雲端建置也可能因依賴版本或 Android 建置設定而失敗。若失敗，請把 Actions 頁面最後一段紅色錯誤訊息貼回來，我可以協助排查。

## 重要提醒
- 此 ZIP 不是 APK；需要雲端工作流程成功後才會產生 APK。
- 此流程不保證第一次就能編譯成功。
- 不要把密碼、存取權杖或其他秘密貼到聊天或程式碼中。
- 在安裝前確認 APK 是你自己的建置產物。

## 下一階段
需要選用並驗證一套可在 Android 上維護的影片處理／匯出方案，實作真正的裁切、分割和 MP4 輸出。不要把尚未實作的按鈕當成已完成功能。
